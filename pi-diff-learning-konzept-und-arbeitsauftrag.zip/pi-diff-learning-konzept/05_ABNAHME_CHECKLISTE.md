# Abnahme-Checkliste

## Architektur

- [ ] Kein zweiter Diff-Parser.
- [ ] Kein `git diff --binary`.
- [ ] Keine Stashes/Commits für Lern-Snapshots.
- [ ] Bestehende Diff-Viewer-Typen werden wiederverwendet.
- [ ] Diff-Viewer publiziert eine schmale Read-only-Änderungsschnittstelle.
- [ ] Diff-Learning ist eigenständig deaktivierbar.

## Funktion

- [ ] `/learn-diff` Toggle funktioniert.
- [ ] `/learn-diff on` funktioniert.
- [ ] `/learn-diff off` funktioniert.
- [ ] `/learn-diff stats` funktioniert.
- [ ] Learn startet standardmäßig OFF.
- [ ] Maximal eine Frage pro Agenten-Turn.
- [ ] `Skip` funktioniert.
- [ ] Lösung erscheint nicht vor der Antwort.
- [ ] Confidence 0–3 wird abgefragt.
- [ ] Lernfortschritt bleibt über Sessions erhalten.

## Lernqualität

- [ ] `+/-` kann trainiert werden.
- [ ] `&&` kann trainiert werden.
- [ ] `||` kann trainiert werden.
- [ ] `!` kann trainiert werden.
- [ ] `return` kann trainiert werden.
- [ ] `throw` kann trainiert werden.
- [ ] `try/catch` kann trainiert werden.
- [ ] Guard-Removal kann trainiert werden.
- [ ] Test-Expectation-Änderungen können trainiert werden.
- [ ] Fragen überschreiten nie die Beweislage des Hunks.
- [ ] Geratenes Richtig wird nicht als volle Beherrschung gewertet.
- [ ] Sicheres Falsch wird als wichtige Fehlvorstellung gewertet.

## UX

- [ ] Keine Frage während der Agent arbeitet.
- [ ] Kein störendes permanentes großes Widget.
- [ ] Lernstatus ist sichtbar, aber kompakt.
- [ ] Kleine Terminalhöhe bleibt nutzbar.
- [ ] Keine neue UI-Animation ist für Funktion nötig.
- [ ] Fehlende geeignete Diffs erzeugen keine künstliche Frage.

## Kompatibilität

- [ ] Shift+Tab unverändert.
- [ ] bestehende Super-Shortcuts unverändert.
- [ ] `/changes` unverändert nutzbar.
- [ ] Diff Live Preview unverändert.
- [ ] Aurora/Frontend-Status nicht beschädigt.
- [ ] Plan/Work-Verhalten nicht verändert.
- [ ] Permissions nicht verändert.
- [ ] Verifier nicht verändert.
- [ ] Recovery nicht verändert.

## Robustheit

- [ ] Tool-Fehler erzeugt keine falsche Frage.
- [ ] Keine Änderung erzeugt keine Frage.
- [ ] Sessionwechsel bereinigt Pending State.
- [ ] Reload dupliziert keine Listener.
- [ ] korrupter Progress Store crasht Pi nicht.
- [ ] Historie ist begrenzt.
- [ ] keine vollständigen Quelldateien im Lernprofil gespeichert.

## Tests

- [ ] Classifier-Tests vorhanden.
- [ ] Question-Bank-Tests vorhanden.
- [ ] Beweisgrenzen getestet.
- [ ] Scoring vollständig getestet.
- [ ] Selector getestet.
- [ ] Persistenz getestet.
- [ ] Integration Event→Quiz→Progress getestet.
- [ ] Negative Integrationsfälle getestet.
- [ ] Diff-Viewer-Regressionen geprüft.
- [ ] Typecheck erfolgreich oder sauber begründete Abweichung.
- [ ] Tests erfolgreich oder sauber begründete Abweichung.
- [ ] Verify erfolgreich oder sauber begründete Abweichung.

## Dokumentation

- [ ] README der Extension vorhanden.
- [ ] Commands erklärt.
- [ ] Confidence erklärt.
- [ ] Persistenz erklärt.
- [ ] MVP-Grenze `edit/write` dokumentiert.
- [ ] Reset/Löschen des Lernprofils dokumentiert.

# Abnahmeentscheidung

**GO**, wenn alle funktionalen, Lernqualitäts-, Kompatibilitäts- und Kern-Testpunkte erfüllt sind.

**NO-GO**, wenn mindestens einer dieser Punkte offen ist:

- falsche/mehrdeutige Quizlösungen
- bestehender Diff-Viewer regressiert
- Shortcut-Konflikt
- Fragen erscheinen während aktiver Agentenarbeit
- Progress kann still beschädigt werden
- neue Diff-Logik dupliziert bestehende Infrastruktur
- Teständerung wird als Produktcode-Beweis dargestellt
