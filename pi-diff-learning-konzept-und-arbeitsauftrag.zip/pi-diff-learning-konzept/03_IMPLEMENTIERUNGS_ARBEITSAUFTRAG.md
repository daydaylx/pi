# Arbeitsauftrag – Pi Diff Learning Extension

## Auftrag

Implementiere im Repository `daydaylx/pi` eine neue, kleine Pi-Extension **Diff Learning**, die den Nutzer anhand realer `edit`-/`write`-Änderungen darin trainiert, Code-Diffs selbst zu verstehen.

Arbeite auf Basis der aktuellen Repository-Struktur und **prüfe vor Änderungen erneut den tatsächlichen HEAD**. Dieser Auftrag wurde gegen `main` auf `4ffcc20e23ab753850a9034e609bde5a8d7ead20` erstellt. Falls sich relevante Strukturen geändert haben, passe die Umsetzung an die neue Realität an und dokumentiere die Abweichung.

---

# 1. Ziel

Die Extension soll während normaler Pi-Arbeit optional Lernfragen zu echten Codeänderungen stellen.

Ablauf:

```text
Pi ändert Code
→ bestehender Diff-Viewer isoliert Änderung
→ Diff-Learning erhält validierten Diff-Hunk
→ bei stabilem Agentenabschluss maximal eine Lernfrage
→ Nutzer wählt Antwort
→ Nutzer gibt Sicherheit 0–3 an
→ Lösung + kurze Erklärung
→ Lernfortschritt wird lokal gespeichert
```

---

# 2. Nicht-Ziele

Nicht bauen:

- keinen allgemeinen Programmierkurs
- keinen zweiten Diff-Viewer
- keinen zweiten Diff-Parser
- keine Git-Snapshot-/Commit-/Stash-Infrastruktur
- keine Bash-Dateimutations-Erkennung im MVP
- kein LLM für Quizfragen im MVP
- keinen Subagenten
- keine Cloud-Synchronisierung
- keine Gamification
- keine große neue TUI
- keine Änderung an Shift+Tab
- keine Umgestaltung bestehender Menüs
- keine automatische Blockierung von `edit` oder `write`

---

# 3. Bestehende Infrastruktur zwingend wiederverwenden

Prüfe und verwende den vorhandenen Bereich:

```text
extensions/diff-viewer/
```

Insbesondere:

```text
types.ts
git-diff.ts
diff-algorithm.ts
change-tracker.ts
index.ts
```

Der bestehende Diff-Viewer isoliert `edit`/`write` bereits über Vorher-/Nachher-Snapshots pro Tool-Aufruf.

**Diese Logik darf nicht dupliziert werden.**

---

# 4. Entkopplung Diff-Viewer ↔ Diff-Learning

Führe eine kleine, explizite Read-only-Schnittstelle ein, über die der Diff-Viewer erfolgreiche tatsächliche Änderungen publiziert.

Bevorzugt:

```text
Extension Event:
diff-viewer.change
```

Payload soll nur die bereits vorhandenen strukturierten Diff-Daten enthalten:

```text
path
toolName
timestamp
stats
hunks
```

Anforderungen:

- Event erst nach erfolgreichem Tool-Resultat.
- Event nur wenn tatsächlich Zeilen hinzugefügt/entfernt wurden.
- Keine Duplizierung der Diff-Berechnung.
- Bestehendes `/changes` darf sich funktional nicht verschlechtern.
- Diff-Learning darf den Diff-Viewer nicht kontrollieren oder mutieren.

Wenn das bestehende Event-System einen gemeinsamen konstanten Channel-Namen verlangt, lege diesen an einem geeigneten Shared-Ort ab, ohne eine neue übergroße Abstraktionsschicht einzuführen.

---

# 5. Neue Extension-Struktur

Erstelle:

```text
extensions/diff-learning/
```

Zielstruktur ungefähr:

```text
index.ts
types.ts
classifier.ts
selector.ts
question-bank.ts
quiz.ts
scoring.ts
progress-store.ts
status.ts
README.md
```

Die genaue Aufteilung darf angepasst werden, wenn eine kleinere Struktur klarer ist.

**Keine monolithische `index.ts` mit der gesamten Logik.**

---

# 6. Lernmodus

Implementiere Session-Zustand:

```text
OFF
ON
```

Startstandard:

```text
OFF
```

Command:

```text
/learn-diff
```

Unterstütze mindestens:

```text
/learn-diff
/learn-diff on
/learn-diff off
/learn-diff stats
```

Bedeutung:

- ohne Argument: Toggle
- `on`: aktivieren
- `off`: deaktivieren
- `stats`: aktuelles Lernprofil kompakt anzeigen

Command muss in den zentralen Command-Katalog integriert werden.

---

# 7. Shortcut

Prüfe alle aktiven registrierten Shortcuts.

Wähle nur dann einen Shortcut, wenn er sicher konfliktfrei ist.

Harte Regeln:

- Shift+Tab unverändert
- vorhandene Super-Menü-Shortcuts unverändert
- keine vorhandene Aktion überschreiben
- Shortcut muss in `/hotkeys`/bestehender Shortcut-Dokumentation sichtbar sein, sofern die Runtime dies über `registerShortcut()` automatisch ermöglicht

Falls kein eindeutig konfliktfreier Shortcut verfügbar ist:

- `/learn-diff` vollständig liefern
- Shortcut nicht erzwingen
- im Abschlussbericht konkrete konfliktfreie Kandidaten nennen

---

# 8. Statusanzeige

Wenn Lernmodus ON:

```text
LEARN
```

kompakt im bestehenden UI-Status anzeigen.

Anforderungen:

- keine dauerhafte große Karte
- kleine Terminals berücksichtigen
- Status ist rein informativ
- Status darf keine bestehende wichtige Statusanzeige verdrängen

Wenn die vorhandene UI-/Aurora-Architektur dafür eine bessere bestehende Status-Schnittstelle besitzt, diese wiederverwenden.

---

# 9. Kandidatenerfassung

Diff-Learning hört auf die publizierten Diff-Events.

Pro Agenten-Turn Kandidaten sammeln.

Jeder Kandidat enthält mindestens:

```text
path
hunk
concepts[]
learningValue
timestamp
```

Ignoriere standardmäßig:

- Lockfiles
- generierte Dateien, soweit anhand bestehender Repo-Regeln eindeutig erkennbar
- reine Imports ohne lernrelevante Logik
- reine Kommentare
- reine Formatierungsänderungen
- extrem große/unklare Hunks

Es ist besser, **keine Frage** zu stellen, als eine mehrdeutige oder falsche Frage zu erzeugen.

---

# 10. Klassifikation v0.1

Unterstütze mindestens:

```text
diff-basics
condition-if
condition-and
condition-or
negation
return
throw
try-catch
fallback
permission-change
guard-removal
test-expectation
validation
```

Keine AST-Pflicht.

MVP darf mit konservativen textuellen/strukturellen Regeln arbeiten.

Regel:

**Classifier muss lieber false-negative als false-positive sein.**

---

# 11. Deterministische Fragen

Erstelle einen kleinen Question Bank.

Fragen dürfen im MVP nur erzeugt werden, wenn aus dem Hunk eindeutig eine korrekte Antwort ableitbar ist.

Standard:

- 4 Optionen, wenn sinnvoll
- 3 Optionen, wenn vier künstlich wären
- binär nur bei elementaren Diff-Grundlagen

Beispiele:

### `&&`

Diff:

```text
- if (admin)
+ if (admin && active)
```

Frage soll sinngemäß prüfen:

```text
Welche Aussage beschreibt die neue Bedingung?
```

### `||`

Prüfen, ob Zugriffs-/Wahrheitsbereich erweitert werden kann.

### `!`

Prüfen, ob Negation erkannt wird.

### `return`

Prüfen, welcher Wert zurückgegeben wird bzw. ob ein Early Return eingeführt/entfernt wurde.

### `throw`

Prüfen, dass ein Fehler ausgelöst und nicht einfach ein Rückgabewert geliefert wird.

### Teständerung

Diff:

```text
- expect(...).toBe("blocked")
+ expect(...).toBe("allowed")
```

Richtige Kernaussage:

```text
Die Test-Erwartung wurde geändert.
```

Falscher Distraktor:

```text
Der Produktcode wurde dadurch nachweislich repariert.
```

---

# 12. Keine Überschreitung der Beweislage

Fragen und Erklärungen dürfen nur behaupten, was der gezeigte Hunk trägt.

Beispiel:

Wenn eine Guard-Clause entfernt wurde:

Erlaubt:

```text
Diese konkrete Prüfung wurde entfernt.
```

Nicht erlaubt:

```text
Im gesamten Projekt gibt es keine Bestätigungsprüfung mehr.
```

Diese Regel ist zentral und muss getestet werden.

---

# 13. Quiz-Ablauf

Nur im TUI-Modus.

Ablauf:

1. ausgewählten Hunk kompakt anzeigen
2. Frage stellen
3. Antwort über native Pi-Auswahl
4. `Skip` erlauben
5. danach Sicherheit 0–3 abfragen
6. Ergebnis anzeigen
7. kurze Erklärung
8. Fortschritt speichern

Wenn Nutzer `Skip` wählt:

- kein Richtig/Falsch-Score
- optional `seen/skipped` zählen
- keine Sicherheit abfragen

---

# 14. Sicherheitsskala

Exakte Bedeutung:

```text
0 = geraten
1 = glaube ich
2 = ziemlich sicher
3 = weiß ich
```

Speichere Antwort und Sicherheit getrennt.

---

# 15. Scoring

Verwende ein transparentes, deterministisches Scoring.

Empfehlung:

```text
richtig + 3 → +3
richtig + 2 → +2
richtig + 1 → +1
richtig + 0 →  0

falsch + 0 → -1
falsch + 1 → -2
falsch + 2 → -3
falsch + 3 → -4
```

Ziel:

- geratenes Richtig nicht überbewerten
- sichere Fehlvorstellungen stark markieren

Speichere zusätzlich rohe Versuche, damit spätere Scoring-Änderungen möglich bleiben.

---

# 16. Persistenz

Persistiere außerhalb des Repositories im Pi-Agent-Verzeichnis.

Schema-Version vorsehen.

Beispielstruktur:

```json
{
  "version": 1,
  "concepts": {},
  "attempts": []
}
```

Anforderungen:

- atomisches Schreiben
- begrenzte Historie oder vernünftiges Größenlimit
- korrupte Datei nicht still überschreiben
- Warnung + sicherer leerer Fallback
- keine Secrets
- kein Quellcode ganzer Dateien speichern

Bei Attempts nur minimale Referenzdaten speichern, z. B.:

```text
concept
correct
confidence
timestamp
projectId/hash
optional path
questionId/templateId
```

Keine vollständigen sensiblen Diffs dauerhaft speichern, sofern für das Lernmodell nicht zwingend nötig.

---

# 17. Auswahlalgorithmus

Wenn mehrere Kandidaten vorhanden sind:

Priorisiere:

1. Konzept mit niedriger Mastery
2. sichere Fehlvorstellung aus Vergangenheit
3. hoher Lernwert
4. kleiner/eindeutiger Hunk
5. lange nicht geübtes Konzept

MVP darf einfacher beginnen:

```text
learningValue
+ weakness bonus
```

Aber Verhalten muss deterministisch testbar sein.

---

# 18. Fragezeitpunkt

Maximal eine Frage pro abgeschlossenem Agenten-Turn.

Keine Frage:

- während Tool-Ausführung
- während laufender Agentenantwort
- während Retry
- während Recovery
- während Verifier noch arbeitet
- wenn Extension OFF
- wenn kein geeigneter Kandidat
- wenn keine interaktive UI
- wenn bereits eine Quiz-Interaktion läuft

Verwende den stabilsten vorhandenen Lifecycle-Hook im aktuellen Runtime-Stand.

Nicht blind einen Eventnamen aus diesem Auftrag übernehmen: **gegen die tatsächlich installierte Pi-API prüfen.**

---

# 19. Session- und Reload-Verhalten

Bei:

```text
session_start
session_shutdown
/reload
branch/session switch
```

muss Zustand sauber bleiben.

Anforderungen:

- keine Listener-Duplikate
- keine alten Pending-Quizzes
- keine Kandidaten aus falscher Session
- persistenter Lernfortschritt bleibt erhalten
- Session-ON/OFF darf nach sauber dokumentierter Entscheidung entweder nur Session-lokal oder global sein

MVP-Empfehlung:

```text
ON/OFF = Session-lokal
Progress = global persistent
```

---

# 20. Bestehende Diff-Viewer-Tests schützen

Vor Refactor:

- bestehende Diff-Suite identifizieren
- Baseline ausführen
- Event-Publikation so ergänzen, dass bestehende Semantik unverändert bleibt

Bestehende `/changes`-Funktion darf keine Regression erhalten.

---

# 21. Neue Tests

Mindestens:

### Classifier

- `+/-`
- `&&`
- `||`
- `!`
- `return`
- `throw`
- `catch`
- Guard removal
- Test expectation change
- irrelevanter Import
- Kommentar
- großer unklarer Hunk

### Question Bank

Für jedes unterstützte Konzept:

- richtige Option eindeutig
- Distraktoren falsch
- keine Behauptung außerhalb des Hunks
- stabile IDs

### Scoring

Alle 8 Kombinationen:

```text
correct/wrong × confidence 0..3
```

### Selector

- Schwäche wird bevorzugt
- ungeeigneter Hunk wird übersprungen
- deterministische Auswahl bei Gleichstand

### Progress Store

- neue Datei
- bestehende Datei
- atomisches Update
- korrupte Datei
- Schema-Version
- bounded history

### Integration

Simuliere:

```text
edit/write
→ diff-viewer.change
→ Kandidat
→ Turn settled
→ Quiz
→ Antwort
→ Confidence
→ Persistenz
```

### Negative Integration

- Tool Error
- keine echte Änderung
- Learn OFF
- kein TUI
- Skip
- Session shutdown
- Reload

---

# 22. Repo-Integration

Prüfe voraussichtlich notwendige Änderungen an:

```text
extensions/diff-viewer/index.ts
extensions/shared/command-catalog.ts
settings.json
tests/run.mjs oder bestehender Suite-Registrierung
```

Neue Dateien unter:

```text
extensions/diff-learning/
tests/suites/...
```

Ändere `setup-core` nur, wenn nachweislich erforderlich.

Nicht vorsorglich Konfigurationsfelder hinzufügen.

---

# 23. Dokumentation

`extensions/diff-learning/README.md` muss enthalten:

- Zweck
- Lernziele
- `/learn-diff` Bedienung
- Shortcut, falls vorhanden
- Confidence-Skala
- was erfasst wird
- was nicht erfasst wird
- Datenschutz/Persistenz
- bekannte MVP-Grenze: nur isolierte `edit`-/`write`-Diffs
- Deinstallation/Zurücksetzen des Lernprofils

---

# 24. Qualitätsregeln

- TypeScript entsprechend bestehendem Repo-Stil
- keine unnötigen Dependencies
- keine neuen externen Pakete für triviale Logik
- keine unbounded Arrays
- keine unbounded Diff-/Datei-Persistenz
- Fehler nicht still verschlucken
- UI muss auf kleinen Terminals funktionieren
- keine vorhandenen Shortcuts kapern
- kein zusätzlicher Modellcall im MVP
- keine Agenten-Prompt-Injektion für die Kernfunktion

---

# 25. Validierung

Vor Abschluss mindestens die bestehenden vorgesehenen Repo-Checks ausführen.

Aus Root-Package sind aktuell vorgesehen:

```text
npm run typecheck
npm run test
npm run verify
```

Nicht automatisch behaupten, alle drei seien nötig/erfolgreich, wenn Repo-Realität sich geändert hat.

Zusätzlich gezielte neue Tests ausführen.

---

# 26. Abschlussbericht

Am Ende liefern:

## Geändert

Dateien und Zweck.

## Wiederverwendet

Welche Diff-Viewer-Komponenten verwendet wurden.

## Verhalten

Wie Toggle, Quiz, Confidence und Persistenz funktionieren.

## Grenzen

Insbesondere:

```text
MVP erfasst edit/write, nicht beliebige Bash-Dateimutationen.
```

## Tests

Exakte Befehle + Ergebnis.

## Offene Risiken

Nur reale Restpunkte.

## Keine Schönfärberei

Wenn ein Teil nicht sauber gelöst ist, als Restproblem benennen.

---

# 27. Abbruch-/Esklationsregeln

Nicht eigenmächtig großen Refactor starten.

Wenn eine der folgenden Annahmen falsch ist:

- Diff-Viewer kann nicht sauber ein Event publizieren
- Runtime bietet keinen stabilen Turn-Abschluss
- Shortcut-System erlaubt keine konfliktfreie Registrierung
- Persistenzpfad ist nicht sauber bestimmbar

dann:

1. Problem konkret belegen.
2. kleinste saubere Alternative wählen.
3. Architektur nicht unnötig aufblasen.
4. Entscheidung im Abschlussbericht dokumentieren.

---

# Abschlusskriterien

Der Auftrag ist erst abgeschlossen, wenn:

- Lernmodus zuverlässig ON/OFF schaltbar ist.
- bestehender Diff-Viewer weiter funktioniert.
- keine zweite Diff-Implementierung entstanden ist.
- mindestens die MVP-Konzepte klassifiziert werden.
- Fragen deterministisch und eindeutig sind.
- Lösung erst nach Nutzerantwort sichtbar wird.
- Confidence 0–3 gespeichert wird.
- Fortschritt über Sessions persistiert.
- maximal eine Frage pro Turn erscheint.
- Skip funktioniert.
- kein Modellcall nötig ist.
- Tests für Kernlogik und Integration vorhanden sind.
- bestehende Shortcuts inklusive Shift+Tab unverändert bleiben.
- Dokumentation vorhanden ist.
