# Pi Diff Learning – Konzept- und Implementierungspaket

## Zweck

Dieses Paket beschreibt eine neue Pi-Erweiterung, die das Lesen und Beurteilen echter Codeänderungen trainiert, während Pi normal weiterarbeitet.

Der Nutzer soll **nicht zum Programmieren gezwungen** werden. Ziel ist zunächst:

- Diffs sicher lesen,
- Kontrollfluss erkennen,
- Rückgabewerte und Fehlerbehandlung verstehen,
- Teständerungen von Produktcodeänderungen unterscheiden,
- sicherheitsrelevante Änderungen bemerken,
- Aussagen des Coding-Agenten gegen den tatsächlichen Diff prüfen.

## Repository-Basis

Planungsstand wurde gegen `daydaylx/pi` auf `main` geprüft.

- Snapshot: `4ffcc20e23ab753850a9034e609bde5a8d7ead20`
- Repository besitzt bereits `extensions/diff-viewer/`.
- Der Diff-Viewer verfolgt `edit` und `write` über Tool-Events.
- Er erzeugt Vorher-/Nachher-Snapshots pro Tool-Aufruf.
- Er stellt bereits `DiffHunk`, `DiffLine`, `DiffStats`, `FileDiff` und `SessionChange` bereit.
- `computeFallbackDiff()` verwendet bereits die bestehende Diff-Implementierung.
- `/changes` existiert bereits für die manuelle Diff-Ansicht.
- `settings.json` lädt Extensions explizit per Allowlist.
- Das zentrale Command-Catalog-System liegt in `extensions/shared/command-catalog.ts`.
- Die aktuelle Keymap belegt u. a. `super+shift+y`, `super+t`, `super+,`, `super+r`.

## Empfohlene Reihenfolge

1. `01_KONZEPT.md`
2. `02_ARCHITEKTUR_UND_WIEDERVERWENDUNG.md`
3. `03_IMPLEMENTIERUNGS_ARBEITSAUFTRAG.md`
4. `04_TESTPLAN.md`
5. `05_ABNAHME_CHECKLISTE.md`
6. `06_RISIKEN_UND_ENTSCHEIDUNGEN.md`

## Wichtigste Architekturentscheidung

**Keinen zweiten Diff-Stack bauen.**

Die Lern-Extension soll die vorhandenen Diff-Datentypen und die bestehende Diff-Berechnung wiederverwenden. Für den MVP werden nur die bereits zuverlässig erfassten `edit`-/`write`-Änderungen verwendet.

Bash-basierte Dateiänderungen, LLM-generierte Quizfragen und komplexe semantische Analyse sind bewusst **nicht Teil des MVP**.

## Zielbild

```text
Pi arbeitet normal
      |
      v
diff-viewer erfasst edit/write
      |
      v
Diff Learning erhält einen relevanten Hunk
      |
      v
deterministische Lernfrage
      |
      v
Antwort + Sicherheit 0..3
      |
      v
Auflösung + kurze Erklärung
      |
      v
lokaler Lernfortschritt
```

## Nicht-Ziel

Die Erweiterung ist kein allgemeiner JavaScript-/TypeScript-Kurs und kein zweiter Agent.

Sie soll den bestehenden Arbeitsfluss ergänzen, nicht dominieren.
