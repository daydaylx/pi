# Architektur und Wiederverwendung

## 1. Bestehende Repo-Bausteine

### `extensions/diff-viewer/`

Dieser Bereich ist für die neue Extension zentral und soll wiederverwendet werden.

Bereits vorhanden:

```text
extensions/diff-viewer/
├── change-tracker.ts
├── diff-algorithm.ts
├── diff-browser.ts
├── diff-entry.ts
├── diff-renderer.ts
├── git-diff.ts
├── index.ts
└── types.ts
```

### Wiederverwenden

Aus `types.ts`:

- `DiffLine`
- `DiffHunk`
- `DiffStats`
- `FileDiff`
- `SessionChange`

Aus `git-diff.ts` / `diff-algorithm.ts`:

- `computeFallbackDiff()`
- vorhandene Hunk-Erzeugung
- vorhandene Größenlimits/Fallbacks
- vorhandene Inline-Diff-Logik nur falls für Darstellung nötig

### Nicht duplizieren

Verbot im MVP:

- zweiter Myers-Diff
- eigener Unified-Diff-Parser
- `git diff --binary`
- eigener Git-Index
- temporäre Commits
- Stash-basierte Snapshots
- kompletter zweiter Diff-Viewer

---

## 2. Problem der aktuellen Kapselung

Der vorhandene `ChangeTracker` lebt derzeit intern in `diff-viewer/index.ts`.

Die Lern-Extension sollte **nicht** direkt auf private Modulzustände zugreifen.

Empfehlung:

### Kleine Shared-Schnittstelle ergänzen

Der Diff-Viewer veröffentlicht nach erfolgreichem `edit`/`write` eine schmale Extension-Event-Payload.

Beispielkonzept:

```text
diff-viewer.change
{
  path,
  toolName,
  timestamp,
  stats,
  hunks
}
```

Wichtig:

- Nur bereits validierte tatsächliche Änderungen publizieren.
- Kein Roh-Dateiinhalt, wenn er nicht benötigt wird.
- Lern-Extension konsumiert das Event read-only.
- Diff-Viewer bleibt allein verantwortlich für Capture und Diff-Berechnung.

Alternative wäre ein gemeinsamer Shared-Service. Für den MVP ist ein Event-Bus einfacher und entkoppelt die Extensions besser.

---

## 3. Neue Extension

Empfohlene Struktur:

```text
extensions/diff-learning/
├── index.ts
├── types.ts
├── classifier.ts
├── selector.ts
├── question-bank.ts
├── quiz.ts
├── scoring.ts
├── progress-store.ts
├── status.ts
└── README.md
```

### `index.ts`

Nur Orchestrierung:

- Command registrieren
- Shortcut registrieren
- Diff-Events abonnieren
- geeignete Hunks sammeln
- bei stabilem Turn eine Frage starten
- Lifecycle sauber zurücksetzen

### `classifier.ts`

Ordnet einen Hunk Lernkonzepten zu.

Beispiele:

```text
diff-basics
condition-and
condition-or
negation
return
throw
try-catch
fallback
permission-change
test-expectation
validation
```

Keine vollständige AST-Analyse im MVP.

### `selector.ts`

Wählt aus Kandidaten den sinnvollsten Hunk.

Priorisierung:

1. Lernwert
2. aktuelle Schwäche
3. kleine Größe
4. eindeutige Frage
5. keine Wiederholung desselben Hunks

### `question-bank.ts`

Deterministische Templates.

Fragen müssen:

- genau eine vertretbare richtige Antwort haben,
- den Diff nicht falsch vereinfachen,
- keine Information behaupten, die außerhalb des Hunks liegt,
- keine Modellantwort benötigen.

### `quiz.ts`

Pi-native UI:

1. Diff darstellen
2. `ctx.ui.select()` für Antwort
3. `ctx.ui.select()` für Sicherheit
4. Auflösung anzeigen
5. Skip unterstützen

Keine komplexe Custom-TUI für MVP.

### `scoring.ts`

Berechnet Mastery / Priorität.

Keine pseudo-präzisen KI-Scores.

Empfohlenes einfaches Modell:

```text
correct + confidence 3 = +3
correct + confidence 2 = +2
correct + confidence 1 = +1
correct + confidence 0 = 0
wrong   + confidence 0 = -1
wrong   + confidence 1 = -2
wrong   + confidence 2 = -3
wrong   + confidence 3 = -4
```

Danach auf bounded Score pro Konzept abbilden.

Das ist bewusst transparent und testbar.

### `progress-store.ts`

Persistiert lokales Lernprofil.

Nicht in Session-Historie als alleinige Quelle legen, weil Fortschritt über Sessions hinweg bestehen soll.

Empfohlener Speicherort:

```text
<pi-agent-dir>/diff-learning/progress.json
```

oder analog zu bestehenden Pi-Konventionen.

Write-Strategie:

- atomisch schreiben,
- Schema-Version speichern,
- korrupte Datei niemals still überschreiben,
- Fallback auf leeres Profil mit Warnung.

---

## 4. Command-Catalog

Das Repo besitzt einen zentralen Command-Katalog in:

```text
extensions/shared/command-catalog.ts
```

Neue Commands dort ergänzen, statt Beschreibungen mehrfach zu hinterlegen.

Empfohlene Kategorie:

```text
code
```

MVP-Eintrag:

```text
learn-diff
```

Optional später:

```text
learn-diff-stats
```

Besser zunächst ein Command mit Argumenten als mehrere Commands.

---

## 5. Settings und Setup

### Nicht in `settings.json` als Lernfortschritt speichern

`settings.json` ist Runtime-/Pi-Konfiguration, kein Telemetrie-/Lernstore.

### Setup-Konfiguration

Für MVP möglichst wenig neue Konfiguration.

Sinnvoll:

```text
learning.enabledDefault
learning.questionFrequency
```

Aber nur wenn wirklich nötig.

Empfehlung für v0.1:

- Modus startet standardmäßig OFF.
- Shortcut/Command schaltet Session-Status um.
- Lernfortschritt wird dauerhaft gespeichert.
- Noch keine Erweiterung von `setup-core/config.ts`, solange keine echte User-Config benötigt wird.

So bleibt der erste Patch klein.

---

## 6. Shortcut

Vor Implementierung alle registrierten Shortcuts prüfen.

Bekannte aktuelle Root-Keybindings:

```text
super+shift+y
super+t
super+,
super+r
```

Zusätzlich existieren Extension-Shortcuts im Command-Katalog, darunter mehrere `Super+...`-Kombinationen.

Regel:

- keine Änderung an Shift+Tab
- keine Überschreibung vorhandener Shortcut-Semantik
- Konfliktprüfung als Test
- wenn kein sicherer Shortcut verfügbar ist: Command zuerst liefern und Shortcut bewusst später wählen

Das ist besser als einen hübschen, aber kollidierenden Shortcut zu erzwingen.

---

## 7. Lifecycle

Die Lernfrage darf nur erscheinen, wenn:

- Lernmodus ON,
- mindestens ein geeigneter Kandidat seit letztem Quiz,
- Agent aktuell nicht arbeitet,
- keine Tool-Ausführung offen,
- keine offene Lernfrage,
- interaktive TUI verfügbar.

Bei Session-Wechsel:

- pending Kandidaten verwerfen oder sauber an die Session binden,
- keine Frage aus einer alten Session in einer neuen Session anzeigen.

Bei `/reload`:

- Event-Listener dürfen nicht dupliziert werden,
- Zustand muss konsistent neu initialisiert werden.

---

## 8. Warum im MVP kein LLM

Die aktuellen Lernziele sind strukturell einfach:

- Diff-Vorher/Nachher
- `&&`
- `||`
- `!`
- `return`
- `throw`
- `catch`
- Test-Erwartung
- entfernte Guard-Clause

Hier ist ein LLM eher ein Risiko:

- zusätzliche Kosten
- variable Lösungen
- Halluzinationen
- schwer testbare Fragen
- unnötige Latenz

LLM-Unterstützung erst, wenn semantische Fragen über mehrere Dateien benötigt werden.

---

## 9. Spätere LLM-Stufe

Nur optional und nach v0.1/v0.2.

LLM darf dann:

- komplexen Hunk erklären,
- Distraktoren vorschlagen,
- mehrere Dateien semantisch zusammenfassen.

Aber:

- Lösung nie vor Nutzerantwort zeigen,
- harte Kontextgrenzen,
- kein Toolzugriff,
- kein Subagent notwendig,
- deterministische Validation der Antwortstruktur,
- deaktivierbar.

---

## 10. Bash-Änderungen

Der vorhandene Diff-Viewer erfasst aktuell `edit`/`write`.

MVP übernimmt exakt diese Grenze.

**Nicht** versuchen, Bash-Dateimutationen halbzuverlässig zu erraten.

v0.2 kann eine separate Strategie evaluieren.

Akzeptable v0.1-Einschränkung:

```text
Lernfragen werden nur aus isoliert erfassten edit/write-Diffs erzeugt.
```

Das muss dokumentiert werden.
