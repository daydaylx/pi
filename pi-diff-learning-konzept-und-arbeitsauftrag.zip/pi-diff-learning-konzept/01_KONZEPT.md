# Konzept – Pi Diff Learning Extension

## 1. Problem

Der Nutzer kann Coding-Agenten auf Aufgabenebene bereits relativ gut beurteilen, hat aber wenig sicheres Wissen beim Lesen konkreter Codeänderungen.

Das Hauptproblem ist nicht fehlende Fähigkeit, selbst Code zu schreiben. Entscheidend ist die Unsicherheit bei Fragen wie:

- Was wurde tatsächlich entfernt oder hinzugefügt?
- Ist eine Bedingung strenger oder lockerer geworden?
- Was macht `return`, `throw`, `catch`, `&&`, `||`, `!`?
- Wurde Produktcode repariert oder nur ein Test passend gemacht?
- Wurde ein Schutzmechanismus entfernt?
- Belegt der Diff wirklich die Zusammenfassung des Agenten?

Ein bloßer Tutor-Modus reicht dafür nicht. Der Lernstoff soll direkt aus den echten Änderungen des laufenden Projekts entstehen.

---

## 2. Produktziel

Die Extension erzeugt aus geeigneten echten Diffs kurze Verständnisübungen.

Normaler Ablauf:

```text
Aufgabe
→ Pi arbeitet
→ Pi ändert Code
→ Arbeit stabil beendet
→ eine relevante Lernfrage
→ Nutzer antwortet
→ Nutzer bewertet eigene Sicherheit
→ Auflösung
→ kurze Erklärung
→ Lernfortschritt wird aktualisiert
```

Die normale Arbeit darf nicht blockiert werden.

---

## 3. Bedienmodell

### Hauptschalter

Ein Shortcut schaltet den Lernmodus ein oder aus.

Empfehlung für die Umsetzung:

- Shortcut **nicht hart festlegen**, bevor die reale registrierte Keymap geprüft wurde.
- Kein Konflikt mit Shift+Tab, Super-Menüs oder vorhandenen Shortcuts.
- Zusätzlich immer Slash-Command anbieten.

Vorgesehene Commands:

```text
/learn-diff
/learn-diff on
/learn-diff off
/learn-diff stats
/learn-diff weak
/learn-diff review
```

MVP muss mindestens `on`, `off`, Toggle und `stats` unterstützen.

### Footer

Nur kompakter Status:

```text
LEARN
```

oder:

```text
LEARN ●
```

Keine große Dauerkarte.

---

## 4. Lerninteraktion

### Schritt 1: Hunk

Die Extension zeigt nur einen kleinen relevanten Diff-Ausschnitt.

### Schritt 2: Frage

Beispiel:

```text
Was hat sich verändert?

A  Fehlender Workspace gibt weiterhin false zurück.
B  Fehlender Workspace löst jetzt einen Fehler aus.
C  Die Workspace-Prüfung wurde vollständig entfernt.
D  Der Code beweist, dass alle Aufrufer den Fehler behandeln.
```

### Schritt 3: Antwort

Der Nutzer wählt A–D.

### Schritt 4: Sicherheit

```text
0  geraten
1  glaube ich
2  ziemlich sicher
3  weiß ich
```

### Schritt 5: Auflösung

Erst jetzt:

```text
Richtig.

Vorher:
Die Funktion gab false zurück.

Nachher:
Sie wirft einen WorkspaceError.

Warum relevant:
Aufrufer können dadurch einen anderen Kontrollfluss erhalten.
```

---

## 5. Warum Multiple Choice statt Stimmt/Stimmt nicht

Binäre Fragen haben eine Zufallschance von 50 %.

Das bisherige Training hat gezeigt, dass richtige Antworten teilweise aus Gefühl oder Raten entstehen können.

Standard deshalb:

- 3–4 Antwortmöglichkeiten.
- Nur elementare Grundlagen dürfen binär sein.
- Eine richtige Antwort mit Sicherheit 0 gilt **nicht** als beherrscht.

---

## 6. Lerngebiete

### Stufe 1 – Diff-Grundlagen

- `-` entfernt
- `+` hinzugefügt
- Kontextzeilen
- vorher / nachher
- einzelne Werte geändert

### Stufe 2 – Kontrolllogik

- `if`
- `else`
- `!`
- `&&`
- `||`
- `true` / `false`

### Stufe 3 – Funktionen

- Funktionsaufruf
- Parameter
- `return`
- Rückgabewert
- Early Return

### Stufe 4 – Fehler

- `try`
- `catch`
- `throw`
- Fehler loggen
- Fehler behandeln
- Fehler verschlucken
- Fallback

### Stufe 5 – Agent kritisch prüfen

- Test-Erwartung geändert
- Schutzprüfung entfernt
- Berechtigung erweitert
- Validierung gelockert
- Test grün ≠ Produktcode bewiesen
- Agentenzusammenfassung ≠ Diff-Beweis

---

## 7. Auswahl geeigneter Änderungen

Hoher Lernwert:

1. Sicherheits-/Berechtigungslogik
2. `if` / Kontrollfluss
3. `try/catch/throw`
4. Validierung
5. Tests
6. `return`
7. Fallbacks
8. kleine Funktionsänderungen

Niedriger Lernwert:

- Formatierung
- Kommentare
- Lockfiles
- generierter Code
- Imports ohne Verhaltensänderung
- reine Umbenennungen
- große mechanische Refactorings

---

## 8. Frequenz

Die Extension darf nicht nerven.

MVP-Standard:

- maximal **eine Frage pro abgeschlossenem Agenten-Turn**
- immer `Skip`
- keine Frage während Tool-Ausführung
- keine Frage während Verifier/Recovery/Retry
- keine Frage, wenn kein geeigneter Hunk existiert

Spätere Intensitäten:

```text
LIGHT
NORMAL
DEEP
```

MVP benötigt nur `NORMAL`.

---

## 9. Lernbewertung

Ein Konzept wird nicht anhand einer einzelnen Antwort beherrscht.

Zu speichern:

- Versuche
- richtig/falsch
- Sicherheit
- Zeitpunkt
- Diff-/Fragetyp
- optional Projektkennung

Interpretation:

```text
richtig + Sicherheit 0 → Zufall/unsicher
richtig + Sicherheit 2–3 → positives Signal
falsch + Sicherheit 0–1 → Wissenslücke
falsch + Sicherheit 3 → mögliche Fehlvorstellung
```

Eine Fehlvorstellung hat höhere Wiederholungspriorität als bloße Unsicherheit.

---

## 10. Erfolgskriterien

Nach realer Nutzung soll der Nutzer zunehmend:

- kleine Diffs ohne Erklärung lesen können,
- `&&`, `||`, `!`, `return`, `throw`, `catch` erkennen,
- Lockerung/Verschärfung einer Bedingung erkennen,
- entfernte Schutzlogik bemerken,
- Teständerungen kritisch beurteilen,
- Agentenaussagen gegen tatsächliche Änderungen prüfen,
- häufiger mit Sicherheit 2–3 korrekt antworten.

Der wichtigste Messwert ist nicht nur Prozent richtig, sondern:

```text
korrekt
+ hohe Sicherheit
+ auf unterschiedlichen echten Diffs wiederholt erkannt
```
