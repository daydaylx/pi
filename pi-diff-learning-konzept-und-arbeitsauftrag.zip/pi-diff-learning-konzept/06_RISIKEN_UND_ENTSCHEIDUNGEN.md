# Risiken und Architekturentscheidungen

## Entscheidung 1 – Keine Abhängigkeit von allgemeinem Tutor

### Entscheidung

Eigene kleine Diff-Learning-Extension.

### Grund

Der gewünschte Lernmodus soll Pi weiterhin normal programmieren lassen. Ein allgemeiner Tutor, der Schreiboperationen blockiert oder den Nutzer zum Selbstprogrammieren zwingt, passt nicht zum Ziel.

---

## Entscheidung 2 – Diff-Viewer als Quelle

### Entscheidung

Bestehenden `extensions/diff-viewer/` als Source of Truth für `edit`/`write`-Diffs verwenden.

### Risiko bei falscher Alternative

Zwei Diff-Systeme könnten unterschiedliche Änderungen zeigen.

---

## Entscheidung 3 – Event statt privatem State-Zugriff

### Entscheidung

Diff-Viewer publiziert strukturierte Änderung nach erfolgreichem Tool-Resultat.

### Vorteil

- geringe Kopplung
- keine Abhängigkeit von internen Tracker-Instanzen
- später auch für andere read-only Features nutzbar

### Risiko

Event-Vertrag darf nicht zum riesigen Shared-API-Layer wachsen.

---

## Entscheidung 4 – Kein AST im MVP

### Grund

Ein AST-basierter Multi-Language-Classifier wäre deutlich komplexer und für die ersten Lernziele nicht nötig.

### Konsequenz

Classifier muss konservativ sein.

Lieber:

```text
keine Frage
```

als:

```text
falsche Lernfrage
```

---

## Entscheidung 5 – Kein LLM im MVP

### Grund

Deterministische Grundlagen lassen sich ohne Modell besser testen.

### Risiko eines frühen LLM

- Kosten
- Latenz
- uneindeutige Lösungen
- Halluzination
- schwierige Regressionstests

---

## Entscheidung 6 – Confidence ist Pflicht

### Grund

Der bisherige Wissenstest hat gezeigt, dass Treffer auch geraten sein können.

Ohne Confidence würde das Lernprofil den tatsächlichen Wissensstand überschätzen.

---

## Entscheidung 7 – Eine Frage pro Turn

### Grund

Lernen darf Produktivität nicht zerstören.

### Später

Intensität kann konfigurierbar werden.

---

## Entscheidung 8 – Session-Status vs. globaler Fortschritt

### Empfehlung

```text
Learn ON/OFF → Session-lokal
Progress → global persistent
```

So startet keine neue Session unerwartet im Quizmodus, während das Lernen dennoch über Zeit messbar bleibt.

---

# Hauptrisiken

## R1 – Mehrdeutige Fragen

**Schwere: hoch**

Eine falsche Lernfrage ist schlimmer als keine Frage.

Gegenmaßnahme:

- konservativer Classifier
- deterministische Templates
- Beweisgrenzen
- Template-Tests

---

## R2 – Diff-Viewer-Regression

**Schwere: hoch**

Die bestehende Änderungserfassung ist produktiv relevant.

Gegenmaßnahme:

- nur additive Event-Publikation
- bestehende Tests zuerst
- `/changes` Regression prüfen

---

## R3 – UI-Unterbrechung

**Schwere: mittel bis hoch**

Wenn Quizfragen mitten in Arbeit, Recovery oder Verifier auftauchen, wird die Erweiterung schnell abgeschaltet.

Gegenmaßnahme:

- stabiler Turn-Abschluss
- eine Frage pro Turn
- Skip
- keine Frage ohne geeigneten Hunk

---

## R4 – Falsche Mastery

**Schwere: mittel**

Nur Prozent richtig misst Raten schlecht.

Gegenmaßnahme:

- Confidence
- sichere Fehlvorstellung stärker gewichten
- mehrere Beispiele pro Konzept

---

## R5 – Shortcut-Konflikt

**Schwere: mittel**

Das Repo hat bereits viele Super-Shortcuts und die bestehende Navigation ist bewusst stabil.

Gegenmaßnahme:

- vor Registrierung prüfen
- Command funktioniert immer
- Shortcut notfalls auf später verschieben

---

## R6 – Persistenz beschädigt

**Schwere: mittel**

Ein kaputtes JSON darf Pi nicht blockieren oder still überschrieben werden.

Gegenmaßnahme:

- atomisches Schreiben
- Schema-Version
- Warnung
- Backup/Recovery-Strategie

---

## R7 – Scope Creep

**Schwere: hoch**

Gefahr:

```text
Tutor
+ LLM
+ Spaced Repetition
+ AST
+ Bash Capture
+ Dashboard
+ Gamification
```

vor einem brauchbaren MVP.

Gegenmaßnahme:

v0.1 strikt begrenzen.

---

# MVP-Grenze

v0.1 ist ausreichend, wenn es:

```text
echter edit/write Diff
→ eindeutige kleine Frage
→ Antwort
→ Confidence
→ Erklärung
→ persistenter Fortschritt
```

zuverlässig erledigt.

Alles andere ist nachrangig.

---

# Entscheidung für v0.2

Erst nach echter Nutzung entscheiden, ob gebraucht werden:

- Bash-Mutationscapture
- mehr Konzepte
- Spaced Repetition
- Projekt-spezifische Profile
- komplexe Statistik

---

# Entscheidung für v0.3

LLM nur dann ergänzen, wenn echte Diffs regelmäßig nicht mit deterministischen Regeln sinnvoll trainierbar sind.

Dann strikt:

- kleiner Kontext
- keine Tools
- keine Lösung vor Antwort
- strukturierte Ausgabe
- optional/deaktivierbar
