# Testplan – Diff Learning

## Ziel

Der Testplan soll verhindern, dass die Extension zwar optisch funktioniert, aber:

- falsche Lernfragen stellt,
- Diffs doppelt oder falsch erfasst,
- den normalen Agentenablauf stört,
- Lernfortschritt falsch bewertet,
- bestehende UI/Shortcuts beschädigt.

---

# A. Diff-Event-Vertrag

## A1 Erfolgreiches Edit

Erwartung:

- genau ein validiertes Change-Event
- korrekter Pfad
- korrekte Hunks
- keine doppelte Publikation

## A2 Erfolgreiches Write

Wie A1.

## A3 Tool Error

Erwartung:

- kein Lern-Change-Event

## A4 Keine tatsächliche Änderung

Erwartung:

- kein Lern-Change-Event

## A5 Mehrere Edits gleiche Datei

Erwartung:

- jeder Tool-Call bleibt sauber isoliert
- Lernsystem darf später den besten Kandidaten wählen
- keine Vermischung mit altem Dirty State

---

# B. Classifier

Fixtures für:

1. `&&` hinzugefügt
2. `||` hinzugefügt
3. `!` hinzugefügt/entfernt
4. Return-Wert geändert
5. `throw` statt `return`
6. `catch` hinzugefügt
7. Guard-Clause entfernt
8. Test-Erwartung geändert
9. Validierung verschärft
10. Validierung gelockert
11. reiner Import
12. Kommentar
13. Formatierung
14. großer uneindeutiger Hunk

Erwartung:

- nur eindeutige Konzepte klassifizieren
- unsichere Fälle ablehnen

---

# C. Question Bank

Für jedes Template prüfen:

- genau eine korrekte Antwort
- mindestens zwei plausible, aber falsche Distraktoren
- keine Option behauptet Informationen außerhalb des Hunks
- richtige Antwortposition darf variieren, falls Randomisierung deterministisch seedbar ist
- stabile Template-ID

Empfehlung für MVP:

**keine echte Zufallsreihenfolge**, wenn sie Tests unnötig erschwert.

---

# D. Beweisgrenzen

Besonders wichtig.

Fixture:

```text
- if (!confirmed) throw ...
```

Erlaubte Aussage:

```text
Diese konkrete Prüfung wurde entfernt.
```

Verbotene Aussage:

```text
Im gesamten Projekt gibt es keine Bestätigung mehr.
```

Fixture Test-Expectation:

```text
- blocked
+ allowed
```

Erlaubt:

```text
Die Erwartung im Test wurde geändert.
```

Nicht erlaubt:

```text
Die Berechtigungslogik wurde repariert.
```

---

# E. Scoring

Tabelle exakt testen:

| korrekt | Confidence | Delta |
|---|---:|---:|
| ja | 0 | 0 |
| ja | 1 | +1 |
| ja | 2 | +2 |
| ja | 3 | +3 |
| nein | 0 | -1 |
| nein | 1 | -2 |
| nein | 2 | -3 |
| nein | 3 | -4 |

Zusätzlich:

- Score Bounds
- attempt count
- lastSeen
- sichere Fehlvorstellung wird hoch priorisiert

---

# F. Selector

Szenarien:

## F1 ein Kandidat

Dieser wird gewählt.

## F2 mehrere Kandidaten, eine klare Schwäche

Schwäche wird bevorzugt.

## F3 alle ungeeignet

Keine Frage.

## F4 gleicher Score

Deterministischer Tie-Break.

## F5 derselbe Hunk bereits abgefragt

Nicht unmittelbar wiederholen.

---

# G. UI-Fluss

## G1 Richtige Antwort

```text
Frage
→ Antwort
→ Confidence
→ Erklärung
→ Persistenz
```

## G2 Falsche Antwort

Gleicher Ablauf, korrekte Auflösung.

## G3 Skip

- keine Confidence
- kein Correct/Wrong
- optional skipped++

## G4 Nicht-TUI

Keine Quiz-UI erzwingen.

## G5 kleines Terminal

Kein unbrauchbarer Vollbilddialog.

---

# H. Lifecycle

## H1 Learn OFF

Keine Quizfrage.

## H2 Learn ON

Geeigneter Kandidat wird nach Turn-Abschluss verwendet.

## H3 Session Shutdown

Pending Kandidaten werden bereinigt.

## H4 Reload

Keine doppelten Listener.

## H5 neue Session

Keine alte Frage taucht auf.

## H6 Verifier/Recovery noch aktiv

Keine vorzeitige Lernfrage.

---

# I. Persistenz

## I1 Erststart

Leeres Profil wird erstellt.

## I2 Neustart

Fortschritt bleibt.

## I3 Korrupte Datei

- Warnung
- kein Crash
- Datei nicht still zerstören

## I4 Schema-Version unbekannt

Sauber ablehnen/migrieren, nicht raten.

## I5 Historienlimit

Datei wächst nicht unbeschränkt.

---

# J. Regressionen Diff-Viewer

Vorher/Nachher vergleichen:

- `/changes`
- Live Preview
- Session reconstruction
- Diff rendering
- Frontend change summary

Event-Publikation darf diese Pfade nicht verändern.

---

# K. Shortcut

Prüfen:

- kein Konflikt mit bestehenden registrierten Shortcuts
- Shift+Tab unverändert
- Super-Menüs unverändert
- `/hotkeys` zeigt neuen Shortcut korrekt, falls registriert

---

# L. Manuelle Abnahme

Mit einer echten kleinen Aufgabe:

1. Learn aktivieren.
2. Agent ändert eine einfache `if`-Bedingung.
3. Arbeit läuft normal zu Ende.
4. Eine Quizfrage erscheint.
5. Nutzer kann ohne Agentenerklärung antworten.
6. Confidence abgeben.
7. Erklärung passt exakt zum Diff.
8. `/learn-diff stats` zeigt Versuch.
9. Pi kann danach normal weiterarbeiten.

Zweites Szenario:

1. Agent ändert nur Import/Formatierung.
2. Keine Lernfrage.

Drittes Szenario:

1. Agent ändert Test-Expectation.
2. Frage prüft, dass nur Test-Erwartung nachweisbar geändert wurde.
